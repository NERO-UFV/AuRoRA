function [aux] = inverte(vetor)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
    aux = [1:size(vetor)]';
    for ii =  1:size(vetor)-1
        aux(ii,1) = vetor(size(vetor,1)-ii,1);
    end
    aux(size(vetor,1),1) = vetor(1,1);
end

