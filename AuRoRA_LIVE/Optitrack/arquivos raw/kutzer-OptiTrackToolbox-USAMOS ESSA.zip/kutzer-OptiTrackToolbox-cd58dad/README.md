# OptiTrackToolbox
MATLAB Toolbox for OptiTrack NatNet SDK
